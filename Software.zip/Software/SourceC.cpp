#include<iostream>
using namespace std;

//struct houdt tijd bij
struct TimeStamp {
	unsigned int uren, minuten, seconden;
};


TimeStamp add_time(TimeStamp t1, TimeStamp t2);
long long time_to_seconds(TimeStamp t1);

int main() {
	//test of de functies werken
	TimeStamp t1{ 12, 56, 0 }, t2{ 1,4,0 }, t4{ 0,59,26 };
	TimeStamp t3;
	int seconden;

	t3 = add_time(t1, t2);
	cout <<"resultaat van de functie add_time:"<< t3.uren << ":" << t3.minuten << ":" << t3.seconden<<endl<<endl;
	
	seconden = time_to_seconds(t4);
	cout << "resultaat van de functie time_to_seconds: "<<seconden<<endl;

	return 0;
}

//functie add_time telt 2 tijdstippen (structs) bij elkaar op en returnt dit als struct
TimeStamp add_time(TimeStamp t1, TimeStamp t2) {
	TimeStamp t3;
	t3.seconden = t1.seconden + t2.seconden;
	t3.minuten = t1.minuten + t2.minuten;
	t3.uren = t1.uren + t2.uren;
	if (t3.seconden >= 60) {
		t3.seconden -= 60;
		t3.minuten +=1;
	}
	if(t3.minuten>=60){
		t3.minuten -= 60;
		t3.uren += 1;
	}
	//Indien je de tijd zoals op de klok wenst te zien moet je dit toevoegen, anders krijg je de tijd zoals op een stopwatch te zien (kan dus hoger dan 24u zijn)
	/*while (t3.uren > 24) {	
		t3.uren -= 24;
	}*/
	return t3;
}

//functie time_to_seconds zet tijd in struct om in seconden
long long time_to_seconds(TimeStamp t1) {
	long long seconden;
	seconden = t1.seconden + t1.minuten * 60 + t1.uren * 3600;
	return seconden;
}

//overload > operator om tijdstippen te vergelijken
bool operator>(TimeStamp& t1, TimeStamp& t2) {
	if (time_to_seconds(t1) > time_to_seconds(t2)) {
		return true;
	}
	else {
		return false;
	}
}