#include <iostream>
#include <string>
#include<cctype>
#include<climits>
#include<cstdlib>
#include<ctime>
using namespace std;

char menu();
int controleerRacer(string* racers, int index, string naam);
void verlengen(string* schildpadden, int& index);
void verkorten(string* schildpadden, int& index);

//programma om schildpadden te verzamelen en te laten racen
int main() {
	string* schildpadden=new string[1]; //array van strings, houdt schildpadden bij
	int wedstrijd = 0; //houdt bij hoeveel wedstrijden gespeeld werken
	int index = 0;//index van schilpadden, houdt bij hoeveel schildpadden er zijn
	char keuze; //keuze van de gebruiker
	string naam; //naam die gebruiker aan schilpad geeft
	srand(time(0)); //random seed

	cout << "--Schildpadden-Race--" << endl << endl;
	keuze = menu(); //laat gebruiker kiezen wat hij/zij wil doen

	while (keuze != 'q') {
		switch (keuze) {
		case 'a':
		{	//vraag naam, controleer of schildpad reeds werd toegevoegd, indien niet, voeg schilpad toe en verleng array met 1 string element
			cout << "Wat is de naam van de schildpad die u wil toevoegen?" << endl;
			cin.ignore(INT_MAX, '\n');
			getline(cin, naam);
			if (controleerRacer(schildpadden, index, naam) == -1) {
				schildpadden[index] = naam;
				verlengen(schildpadden, index);
			}
			else {
				cout << naam << " was al toegevoegd aan de race" << endl;
			}
		}
		break;
		case 'b':
		{	//Vraag naam, controleer of schildpad aanwezig is, indien ja, verwijder de schildpad, verkort de array met 1 string element
			if (index == 0) {
				cout << "Er zijn geen schildpadden aan de race toegevoegd. " << endl;
			}
			else {
				cout << "Wat is de naam van de schildpad die u wil verwijderen?" << endl;
				cin.ignore(INT_MAX, '\n');
				getline(cin, naam);
				if (controleerRacer(schildpadden, index, naam) == -1) {
					cout << naam << " was niet gevonden." << endl;
				}
				else {
					for (int i = controleerRacer(schildpadden, index, naam); i < index - 1; i++) {
						schildpadden[i] = schildpadden[i + 1];
					}
					schildpadden[index - 1] = "";
					verkorten(schildpadden, index);
				}
			}
		}
		break;
		case 'c':
		{	//controleer of er schildpadden zijn, indien ja, print hun namen
			if (index == 0) {
				cout << "Er zijn geen schildpadden aan de race toegevoegd." << endl;
			}
			else {
				cout << "Lijst racers:" << endl;
				for (int i = 0; i < index; i++) {
					cout << schildpadden[i] << endl;
				}
			}
		}
		break;
		case 'd':
		{	//controleer of er minstens 2 schildpaden zijn, indien ja, laat een random schildpad de race winnen
			if (index == 0) {
				cout << "Er zijn geen schildpadden aan de race toegevoegd." << endl;
			}
			else if (index == 1) {
				cout << "Er is maar 1 schildpad aan de wedstrijd toegevoegd, dit is onvoldoende voor een race." << endl;
			}
			else {
				wedstrijd++;

				cout << "Race " << wedstrijd << ": " << schildpadden[rand() % index] << " is de winnaar!" << endl;
			}
		}
		break;
		}
		keuze = menu(); //vraag gebruiker opnieuw wat hij/zij wil doen
	}

	delete[] schildpadden; //delete de dynamische array
	schildpadden = NULL;
	return 0;
}

//De functie menu toont een menu aan de gebruiker stuurt keuze terug dmv char variabele
char menu() {
	char keuze;

	cout << "a) Schildpad toevoegen" << endl;
	cout << "b) Schildpad verwijderen" << endl;
	cout << "c) Schildpadden tonen" << endl;
	cout << "d) Race starten" << endl;
	cout << "q) Programma stoppen" << endl;

	cin >> keuze;
	keuze = tolower(keuze);
	while (keuze < 'a' || (keuze > 'd' && keuze != 'q')) {
		cout << "Ongeldige keuze, probeer opnieuw: ";
		cin.clear();
		cin.ignore(INT_MAX, '\n');
		cin >> keuze;
	}
	return keuze;
}

//controleerRacer is een functie die checkt of een schildpad met een bepaalde naam reeds werd toegevoegd, indien ja geeft ze de plaat van de schildpad terug.
int controleerRacer(string* racers, int index, string naam) {
	for (int i = 0; i < index; i++) {
		if (racers[i] == naam) {
			return i;
		}
	}
	return -1;
}

//de functie verlengen verlengt de array van strings met 1 element
void verlengen(string* schildpadden, int& index) {
	index++;
	string* temp = new string[index+1];
	for (int i = 0; i < index; i++) {
		temp[i] = schildpadden[i];
	}
	delete[] schildpadden;
	schildpadden = temp;
	temp = NULL;
}

//de functie verkorten verkort de array van strings met 1 element
void verkorten(string* schildpadden, int& index) {
	index--;
	string* temp = new string[index+1];
	for (int i = 0; i < index; i++) {
		temp[i] = schildpadden[i];
	}
	delete[]schildpadden;
	schildpadden = temp;
	temp = NULL;
}