#include<iostream>
#include<climits>
using namespace std;

void veiligeInt(int& getal, int min, int max);
void printBrug(int breedte, int hoogte, int diepte);

int main() {
	//vraag invoer voor breedte, hoogte en diepte dmv veiligeInt functie
	int breedte, hoogte, diepte;
	cout << "Geef de breedte (>=3):" << endl;
	veiligeInt(breedte, 3, INT_MAX);
	cout << "Geef de hoogte (>=3):" << endl;
	veiligeInt(hoogte, 3, INT_MAX);
	cout << "Geef de diepte (<="<<breedte/2<<") " << endl;
	veiligeInt(diepte, 1, breedte / 2);

	cout << endl << endl;
	//print brug dmv printBrug functie
	printBrug(breedte, hoogte, diepte);

	return 0;
}

//veiligeInt vraagt invoer van de gebruiker en checkt of deze binnen het gegeven minimum en maximum is
void veiligeInt(int& getal, int min, int max) { 
	while (!(cin >> getal) || getal<min || getal>max) {
		cout << "Ongeldige invoer, de invoer moet groter zijn dan " << min - 1;
		if (max < INT_MAX) {
			cout << " en kleiner dan " << max;
		}
		cout << endl;
		cin.clear();
		cin.ignore(INT_MAX, '\n');
	}
}

//printBrug geeft een brug weer op het scherm met gegeven hoogte, breedte en diepte
void printBrug(int breedte, int hoogte, int diepte) {
	for (int i = 0; i < diepte; i++) {
		for (int j = 0; j < breedte; j++) {
			cout << "*";
		}
		cout << endl;
	}

	for (int i = 0; i < hoogte-diepte; i++) {
		for (int j = 0; j < breedte; j++) {
			if (j < diepte || j >= breedte - diepte) {
				cout << "*";
			}
			else {
				cout << " ";
			}
		}
		cout << endl;
	}

}