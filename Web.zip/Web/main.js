console.log("javascript loaded");
/* ###### 
1) Boodschap tonen 
##### */

let hasRunBefore=false;
let notice=document.getElementById("notice")

window.onload = function () {
    window.addEventListener("scroll", function(){
        notice.classList.remove("hidden");
    })
       
}

/*window.onload=()=>{
    window.addEventListener("scroll", function(){
        notice.classList.remove("hidden");
    })
}*/



/*
Zodra de gebruiker begint te scrollen wordt de boodschap getoond 
die je onderaan de html-pagina vindt. (de div 'notice')


Koppel hiervoor het scroll event aan het window opject.
Ter vergelijking: 
Voor een click event plaatsen we de listener bij een 'node' object 
dat we hebben opgehaald met een DOM query.

Voor dit scroll event plaats je de listener bij het 'document' object
dat standaard beschikbaar is.
Zoals bijvoorbeeld in document.getElementById()
*/


/*  
##### 
2) Boodschap sluiten 
##### 
*/
let ok=document.getElementById("ok");
ok.addEventListener("click", function(){
    notice.classList.add("hidden");
    event.preventDefault();
})
/*
Als je Klikt op 'ok' in plaats van 'niet ok' dan verdwijnt de boodschap.
 */


/* 
###### 
3) Aangespast boodschap 
##### 
Als je klikt op 'niet ok' in plaats van 'ok' 
dan verandert verandert de inhoud van de header in de titel: 
"Je mag deze site niet bezoeken"
*/
let intro=document.querySelector(".intro p");

let niet=document.getElementById("niet");
niet.addEventListener("click", function(){
    document.getElementById("titel").innerHTML="U kan deze pagina niet bezoeken";
    intro.classList.add("hidden");
})


/* KRIJG JE HET NIET AAN DE PRAAT?
Schrijf de code zo goed als je kan.
Ook een niet werkend script wordt verbeterd.

*/